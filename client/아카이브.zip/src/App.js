import './App.css';
import { Settings } from './components/Users/Settings';

function App() {
  return <Settings />;
}

export default App;
