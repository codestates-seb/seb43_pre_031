import styled from 'styled-components';

export const Settings = () => {
  return (
    <>
      <h2>Edit your profile</h2>
      <h2>Public information</h2>
      <span>Display name</span>
      <input></input>
      <span>Location</span>
      <input></input>
      <span>Title</span>
      <input></input>
      <span>About me</span>
      <input></input>
      <h2>Links</h2>
      <span>Website link</span>
      <input></input>
      <span>Twitter link or username</span>
      <input></input>
      <span>GitHub link or username</span>
      <input></input>
      <h2>Private information</h2>
      <sapn>Full name</sapn>
      <input></input>
    </>
  );
};

export const SettingContent = styled.div`
  width: 35rem;
  margin: 1.2rem 1.2rem 1.2rem 0;
  @media screen and (max-width: 980px) {
    width: 100%;
    li {
      width: 25% !important;
    }
  }
  .flex {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    p {
      font-size: 1.3rem;
      margin-bottom: 0;
      color: ${(props) => props.theme.color.black500};
      cursor: pointer;
    }
    div {
      width: 100%;
      display: flex;
      align-items: center;
      p {
        display: flex;
        flex: 1;
        justify-content: space-between;
        color: ${(props) => props.theme.color.blue500};
        &:hover {
          color: ${(props) => props.theme.color.blue300};
        }
      }
    }
  }
  .flex.hover {
    p {
      color: ${(props) => props.theme.color.black500};
      &:hover {
        color: ${(props) => props.theme.color.black100};
      }
    }
  }
  h2 {
    font-size: 2.1rem;
    font-weight: 400;
    color: ${(props) => props.theme.color.black1000};
    margin-bottom: 0.9rem;
  }
  .left {
    width: 100%;
    border-radius: 0.5rem;
    border: 1px solid ${(props) => props.theme.color.black100};
    display: flex;
    margin-bottom: 2.2rem;
    padding: 1.2rem;
    svg {
      width: 1.5rem;
      height: 1.5rem;
      margin-right: 0.5rem;
    }
    p {
      margin: 0;
    }
    ul {
      width: 100%;
      justify-content: center;
      li {
        width: 50%;
        height: 4rem;
        display: flex;
        float: left;
        flex-direction: column;
        justify-content: flex-start;
      }
      li:first-child,
      li:nth-child(2) {
        margin-bottom: 1.2rem;
      }
    }
    span {
      font-size: 1.3rem;
      margin-bottom: 0.9rem;
      color: 1px solid ${(props) => props.theme.color.black1000};
    }
  }
   .user-wrapper {
    width: 100%;
    height: fit-content;
    display: flex;
    align-items: center;
    .user-imgBox {
      width: 128px;
      height: 128px;
      border-radius: 5px;
      margin-right: 10px;
      cursor: pointer;
      background-image: url(https://www.gravatar.com/avatar/4155f0d14a5ae70fc6670903206da4e8?s=256&d=identicon&r=PG&f=y&so-version=2);
      background-size: contain;
      background-repeat: no-repeat;
    }
    .right {
        border-radius: 0.5rem;
        border: 1px solid ${(props) => props.theme.color.black100};
        padding: 3.2rem;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        background-color: ${(props) => props.theme.color.black050};
        margin-bottom: 2.3rem;
    }
`;
